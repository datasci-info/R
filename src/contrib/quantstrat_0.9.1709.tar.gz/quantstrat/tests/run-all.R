require(testthat)
require(quantstrat)

try(test_package("quantstrat"))

