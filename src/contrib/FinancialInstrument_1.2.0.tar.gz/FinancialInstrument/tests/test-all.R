library(testthat)
library(FinancialInstrument)

test_package("FinancialInstrument")